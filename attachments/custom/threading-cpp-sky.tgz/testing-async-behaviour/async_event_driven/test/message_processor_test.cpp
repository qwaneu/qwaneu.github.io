#include "gtest/gtest.h"
#include "message_processor.h"

TEST(message_processor_test, InvertsMessage_naive)
{
    std::string result;
    MessageProcessor message_processor;
    message_processor.process_message("123", ([&result] (std::string message) { result = message; } ));
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    ASSERT_EQ("321", result);
}


