#ifndef _MESSAGE_PROCESSOR_H
#define _MESSAGE_PROCESSOR_H
#include <thread>
#include <condition_variable>
#include "thread_safe_queue.h"

class MessageProcessor {
public:
    MessageProcessor();
    virtual ~MessageProcessor() {
        stop();
    }

    void start();
    void stop() {
        {
            std::unique_lock<std::mutex> lk(_m);
            _goOn = false;
        }
        _processing_thread->join();
    }

    void enqueue(const std::string string);

    std::string dequeue();

private:
    bool _goOn;
    ThreadSafeQueue<std::string> _input_queue;
    ThreadSafeQueue<std::string> _output_queue;
    std::condition_variable _started;
    std::mutex _m;
    std::unique_ptr<std::thread> _processing_thread;
};

#endif // _MESSAGE_PROCESSOR_H
