# TODO remove? The testing-async-behaviour directory has probably moved to [threading-cpp](https://gitea.apps.sustainabledelivery.com/QWAN/threading-cpp/src/branch/master/README.md), but the source did not get removed.

# run local desktop

``` bash
./build.sh && docker run -p 8090:8080 525595969507.dkr.ecr.eu-central-1.amazonaws.com/qwan/course-vendingmachine-cpp:spike
```

