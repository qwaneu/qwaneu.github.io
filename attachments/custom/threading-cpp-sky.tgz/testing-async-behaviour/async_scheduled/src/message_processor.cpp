#include "message_processor.h"
#include <memory>
#include <thread>
#include <iostream>
#include <utility>
#include "hours_and_minutes.h"


ScheduledMessageProcessor::ScheduledMessageProcessor(MessageProcessorListener listener): _timer_thread() {
    this->_listener = listener;
}

void ScheduledMessageProcessor::processMessage(std::string message,const std::chrono::hours& hours, const std::chrono::minutes& minutes) {
    _timer_thread = std::make_unique<std::thread>([&]() {
        // wait for hours and minutes
        std::this_thread::sleep_for(delta_in_milliseconds(minutes, hours));

        std::string reversed;
        for (int i = message.length() - 1; i >= 0; --i) {
            reversed = reversed + message[i];
        }
        _listener(reversed);
    });
}
