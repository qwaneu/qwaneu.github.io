#ifndef _MESSAGE_PROCESSOR_H
#define _MESSAGE_PROCESSOR_H
#include <thread>
#include <string>
#include <functional>

typedef std::function<void (std::string)> MessageProcessorListener;

class ScheduledMessageProcessor {

public:
    explicit ScheduledMessageProcessor(MessageProcessorListener function1);
    virtual ~ScheduledMessageProcessor() {
        _timer_thread->join();
    }

    void processMessage(std::string message, const std::chrono::hours& hours, const std::chrono::minutes& minutes);
private:
    MessageProcessorListener _listener;
    std::unique_ptr<std::thread> _timer_thread;

};


#endif // _MESSAGE_PROCESSOR_H
