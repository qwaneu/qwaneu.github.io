#include "gtest/gtest.h"
#include "message_processor.h"

TEST(message_processor_test, InvertsMessages_naive)
{
    MessageProcessor processor;
    processor.start();
    processor.enqueue("123");
    std::this_thread::sleep_for(std::chrono::milliseconds(301));
    std::string result = processor.dequeue();
    ASSERT_EQ("321", result);
}

TEST(message_processor_test, ProcessesThemInOrder_naive)
{
    MessageProcessor processor;
    processor.start();
    processor.enqueue("123");
    processor.enqueue("456");
    std::this_thread::sleep_for(std::chrono::milliseconds(350));
    std::string result1 = processor.dequeue();
    ASSERT_EQ("321", result1);
    std::this_thread::sleep_for(std::chrono::milliseconds(350));
    std::string result2 = processor.dequeue();
    ASSERT_EQ("654", result2);
}



