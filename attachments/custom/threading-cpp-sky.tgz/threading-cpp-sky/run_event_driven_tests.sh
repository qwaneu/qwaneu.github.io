#!/bin/bash

mkdir -p build && cd build

run_all_tests() {
  async_event_driven/test/async_event_driven_tst
}

cmake .. && cmake --build . && run_all_tests
