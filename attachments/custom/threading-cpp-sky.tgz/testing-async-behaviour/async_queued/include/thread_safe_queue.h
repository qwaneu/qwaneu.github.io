//
// Created by rob on 5-6-23.
//

#ifndef ASYNC_THREAD_SAFE_QUEUE_H
#define ASYNC_THREAD_SAFE_QUEUE_H
#include <condition_variable>
#include <queue>

template<class T>
class ThreadSafeQueue {
public:
    ThreadSafeQueue(): _queue(), _m() {}
    virtual ~ThreadSafeQueue() = default;
    void enqueue(const T element) {
        std::unique_lock<std::mutex> lk(_m);
        _queue.push(element);
    }
    T dequeue() {
        std::unique_lock<std::mutex> lk(_m);
        if (_queue.empty()) return "";
        T& element = _queue.front();
        _queue.pop();
        return element;
    }

private:
    std::mutex _m;
    std::queue<T> _queue;
};

#endif //ASYNC_THREAD_SAFE_QUEUE_H
