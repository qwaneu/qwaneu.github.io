#!/bin/bash
set -e
VERSION=0.1.2
REPO="525595969507.dkr.ecr.eu-central-1.amazonaws.com/qwan/threading-cpp"
BASE_IMAGE="525595969507.dkr.ecr.eu-central-1.amazonaws.com/qwan/course-cpp:latest"

command=$1
case $command in
  push)
    docker push $REPO:$VERSION
    ;;
  *)
    docker pull $BASE_IMAGE
    docker build . -t $REPO:$VERSION
    ;;
esac
