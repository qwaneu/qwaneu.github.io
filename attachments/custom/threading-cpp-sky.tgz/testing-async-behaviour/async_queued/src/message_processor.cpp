#include "message_processor.h"

MessageProcessor::MessageProcessor() : _goOn(false), _input_queue(), _output_queue(), _started(), _m() {
}

void MessageProcessor::start() {
    _processing_thread = std::make_unique<std::thread>([&]() {
        {
            std::unique_lock<std::mutex> lk(_m);
            _goOn = true;
        }
        _started.notify_all();
        while(_goOn) {
            std::string input = _input_queue.dequeue();
            if (input != "") {
                std::string output = "";
                for (char& c: input) {
                    output.insert(0, 1, c);
                    std::this_thread::sleep_for(std::chrono::milliseconds(100));
                }
                _output_queue.enqueue(output);
            }
        }
    });
    {
        std::unique_lock<std::mutex> lk(_m);
        _started.wait_for(lk, std::chrono::milliseconds(1000), [&] { return _goOn; });
    }
}

void MessageProcessor::enqueue(const std::string string) {
    _input_queue.enqueue(string);
}

std::string MessageProcessor::dequeue() {
    return _output_queue.dequeue();
}
