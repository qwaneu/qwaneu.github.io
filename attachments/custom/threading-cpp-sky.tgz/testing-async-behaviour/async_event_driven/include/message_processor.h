#ifndef _MESSAGE_PROCESSOR_H
#define _MESSAGE_PROCESSOR_H
#include <thread>
#include <condition_variable>

typedef std::function<void (std::string)> MessageProcessorListener;

class MessageProcessor {
public:
    virtual ~MessageProcessor()  {
        processing_thread->join();
    };
    void process_message(std::string message, MessageProcessorListener listener)
    {
        processing_thread = std::make_unique<std::thread>([&]() {
            std::string output = "";
            for (char& c: message) {
                output.insert(0, 1, c);
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
            listener(output);
        });
    }
private:
    std::unique_ptr<std::thread> processing_thread;

};

#endif // _MESSAGE_PROCESSOR_H
