#include "gtest/gtest.h"
#include "message_processor.h"

// RUN with fswatch -o async_event_driven | while read f; do  ./run_event_driven_tests.sh; done

// next step: extract probe to function
//
void probe(std::string &result, std::string expected, unsigned step_ms = 10, unsigned max_time_ms = 1000 ) {
  
    int time_spent = 0;
    while(result != expected && time_spent <= max_time_ms) {
      std::this_thread::sleep_for(std::chrono::milliseconds(step_ms));
      time_spent += 10;
    }
}

void dummy_sleeper() {}

// Wrote the integration test first, did not read instructions carefully :-). I do think it is easier this way.
TEST(message_processor_test, InvertsMessage_integration_with_probe)
{
    std::string result;
    MessageProcessor message_processor;
    message_processor.process_message("123",
                                      ([&result] (std::string message) { result = message; }),
                                       dummy_sleeper );
    auto expected = "321";
    probe(result, expected);
    ASSERT_EQ(expected, result);
}

TEST(message_processor_test, reverts_non_empty_message) {
  ASSERT_EQ("olleH", reverse("Hello"));
}

TEST(message_processor_test, revertedd_empty_message_is_empty) {
  ASSERT_EQ("", reverse(""));
}

TEST(message_processor_test, revertedd_empty_message_is_) {
  ASSERT_EQ("1", reverse("1"));
}
/**
I am trying to pass dummy_sleeper, but get

   */

