#include <thread>
#include "gtest/gtest.h"
#include "hours_and_minutes.h"


TEST(hours_and_minutes, delta_for_one_minute)
{
    HoursAndMinutes hm = HoursAndMinutes::now();
    const std::chrono::minutes inAMinute = hm.minutes() + std::chrono::minutes(1);
    std::chrono::milliseconds delta = delta_in_milliseconds(inAMinute, hm.hours());
    ASSERT_EQ(delta.count(), 60000);
}