#!/bin/bash
set -a
. donstro/remote.env
export SERVER_NAME=${LAB_HTTPS_DOMAIN:-localhost}

echo using the following environment
env | grep SERVER_NAME
cat donstro/remote.env

docker-compose -f donstro/docker-compose.yml up
set +a
