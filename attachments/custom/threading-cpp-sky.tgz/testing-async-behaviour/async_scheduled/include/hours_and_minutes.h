
#ifndef ASYNC_HOURS_AND_MINUTES_H
#define ASYNC_HOURS_AND_MINUTES_H
#include <chrono>

class HoursAndMinutes {
public:
    explicit HoursAndMinutes(std::chrono::time_point<std::chrono::system_clock> time_point): _hours(), _minutes() {
        auto system_time = std::chrono::system_clock::to_time_t(time_point);
        std::tm* local_time = std::localtime(&system_time);
        _hours = std::chrono::hours(local_time->tm_hour);
        _minutes = std::chrono::minutes(local_time->tm_min);
    };

    [[nodiscard]] const std::chrono::hours &hours() const {
        return _hours;
    }

    [[nodiscard]] const std::chrono::minutes &minutes() const {
        return _minutes;
    }

    static HoursAndMinutes now() {
        return HoursAndMinutes(std::chrono::system_clock::now());
    }

private:
    std::chrono::minutes _minutes;
    std::chrono::hours _hours;
};

std::chrono::milliseconds delta_in_milliseconds(const std::chrono::minutes &minutes, const std::chrono::hours &hours);


#endif //ASYNC_HOURS_AND_MINUTES_H
