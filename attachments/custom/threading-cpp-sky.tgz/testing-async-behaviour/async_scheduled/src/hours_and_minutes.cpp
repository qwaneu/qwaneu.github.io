#include "hours_and_minutes.h"

std::chrono::milliseconds delta_in_milliseconds(const std::chrono::minutes &minutes, const std::chrono::hours &hours) {
    HoursAndMinutes hm = HoursAndMinutes::now();
    const auto delta_h = hours - hm.hours();
    const auto delta_m = minutes - hm.minutes();
    std::chrono::milliseconds wakeUpTime = delta_h + delta_m;
    return wakeUpTime;
}

