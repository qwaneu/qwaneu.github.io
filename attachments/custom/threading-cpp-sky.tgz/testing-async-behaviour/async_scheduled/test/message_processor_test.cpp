#include <thread>
#include "gtest/gtest.h"
#include "message_processor.h"

#include "hours_and_minutes.h"

TEST(message_processor_test, reverses_on_schedule) {
    std::string result = "";
    MessageProcessorListener listener = ([&result](std::string message) { result = message; });
    ScheduledMessageProcessor processor(listener);

    HoursAndMinutes hm = HoursAndMinutes::now();

    auto at_minutes = hm.minutes() + std::chrono::minutes(1);

    processor.processMessage("123", hm.hours(), at_minutes);
    std::this_thread::sleep_for(std::chrono::milliseconds(70 * 1000));

    ASSERT_EQ("321", result);
}




