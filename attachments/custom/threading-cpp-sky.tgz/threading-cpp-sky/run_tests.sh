#!/bin/bash

mkdir -p build && cd build

run_all_tests() {
  async_event_driven/test/async_event_driven_tst
  async_queued/test/async_queued_tst
  async_scheduled/test/async_scheduled_tst
}

cmake .. && cmake --build . && run_all_tests
