#!/bin/bash


run_all_tests() {
    cd build
    dirty_argument_capture/test/dirty_argument_capture_tst
    dirty_obscure/test/dirty_obscure_tst
}

./build-cpp.sh && run_all_tests
