# TODO autotest runs too often
inotifywait (on willems laptop) does not seemed to wait. Increased the `sleep` from 1 to 10, but still runs again with no discernible changes.

# Installation

```
 python3 -m pip install --user scons
```

[What is SCons?](https://scons.org/). It is 'a software construction tool'. Builds C, C++, Java and some other things.

# Build

`scons`

# Test

`scons test`

# run local desktop

``` bash
./build.sh && docker run -p 8090:8080 525595969507.dkr.ecr.eu-central-1.amazonaws.com/qwan/course-vendingmachine-cpp:spike
```

