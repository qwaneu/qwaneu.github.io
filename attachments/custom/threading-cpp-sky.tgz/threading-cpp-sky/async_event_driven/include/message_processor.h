#ifndef _MESSAGE_PROCESSOR_H
#define _MESSAGE_PROCESSOR_H
#include <thread>
#include <condition_variable>

void default_sleeper()  {}

std::string reverse(std::string message, std::function<void()> sleeper = default_sleeper) {
            std::string output = "";
            for (char& c: message) {
                output.insert(0, 1, c);
                sleeper();
            }
            return output;
}

typedef std::function<void (std::string)> MessageProcessorListener;

void actual_sleeper() {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
}

class MessageProcessor {
public:
    virtual ~MessageProcessor()  {
        processing_thread->join();
    };
  void process_message(std::string message,
                       MessageProcessorListener listener,
                       std::function<void()>  sleeper = actual_sleeper)
    {
        processing_thread = std::make_unique<std::thread>([&]() {
          std::string output = reverse(message, sleeper);
          listener(output);
        });
    }

private:
    std::unique_ptr<std::thread> processing_thread;

};


#endif // _MESSAGE_PROCESSOR_H

/*
 Hdo I define sleeper as a function parameter, and then call it inside the for loop?

You need to declare `sleeper` as a callable (e.g., `std::function<void()>` or a template parameter), *not* `void`. Also, your lambda captures `&` — but the `sleeper` parameter is local, so it's captured correctly. However, passing `void` as a function type won’t work.

**Fix:**

```cpp
void process_message(std::string message, MessageProcessorListener listener,
                     std::function<void()> sleeper)
{
    processing_thread = std::make_unique<std::thread>([=, &message]() mutable {
        std::string output = "";
        for (char c : message) {
            output.insert(0, 1, c);
            sleeper();
        }
        listener(output);
    });
}
```

Or use a template for flexibility:

```cpp
template <typename Sleeper>
void process_message(std::string message, MessageProcessorListener listener, Sleeper&& sleeper)
{
    processing_thread = std::make_unique<std::thread>([=, &message]() mutable {
        std::string output = "";
        for (char c : message) {
            output.insert(0, 1, c);
            sleeper();
        }
        listener(output);
    });
}
```

Then call with `actual_sleeper`:

```cpp
mp.process_message("hello", listener, actual_sleeper);
```

Also, avoid calling `join()` in destructor (risk of deadlock if already joined); better to join explicitly or check state.
  */
